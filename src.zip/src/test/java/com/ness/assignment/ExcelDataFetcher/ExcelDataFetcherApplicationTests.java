package com.ness.assignment.ExcelDataFetcher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelDataFetcherApplicationTests {

	@Test
	void contextLoads() {
	}

}

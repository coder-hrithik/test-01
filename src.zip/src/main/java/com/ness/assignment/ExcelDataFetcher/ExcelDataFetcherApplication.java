package com.ness.assignment.ExcelDataFetcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelDataFetcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelDataFetcherApplication.class, args);
	}

}

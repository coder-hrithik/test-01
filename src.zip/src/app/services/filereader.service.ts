import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FilereaderService {

  constructor(private http:HttpClient) { }

  reader(formData:File){
    console.log(formData)
    return this.http.post("http://localhost:8080/upload",formData);
  }

  updateFile(formData:any) {
    console.log(formData);
    return this.http.post("http://localhost:8080/append",formData);
  }
}
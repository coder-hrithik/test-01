import { Component } from '@angular/core';
import { FilereaderService } from './services/filereader.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Excellfront';

data :any;
blob:any=0;
lnk:string=''
downloadExcelFile(): void {
  this.updateFile()
  // Prepare your data in the desired format, for example:
  
  // blob = new Blob([data], { type: 'text/plain' });
  // Create a new workbook and worksheet
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(this.data);

  // Add the worksheet to the workbook
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

  // Generate the Excel file
  const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

  // Create a Blob from the Excel buffer
  let sheet = new Blob([excelBuffer], { type: 'application/octet-stream' });

  // Create a temporary URL for the Blob
  const url = window.URL.createObjectURL(sheet);

  // Create a link element and set its properties
  const link = document.createElement('a');
  link.href = url;
  this.lnk=url
  link.download = 'data.xlsx';

  // Programmatically click the link to start the download
  // link.click();

  // Clean up the temporary URL
  // window.URL.revokeObjectURL(url);
  // this.blob = new Blob([sheet], { type: 'application/octet-stream' });
}

  constructor(private service:FilereaderService){}
  // data:any;
  
  //downloadUrl = URL.createObjectURL(this.blob);

  
  selectedFile: File | null = null;

  handleFileInput(event:any): void {

      // Perform further actions with the file
      this.selectedFile=event.target.files[0];
      this.uploadFile();
    
  }
  updateEvent(e:any,i:number,j:number){
    this.data[i][j]=e.target.value
  }

  updateFile(): void {
    if(this.data) {
      this.service.updateFile(this.data).subscribe(res=>{
        this.data=JSON.parse(JSON.stringify(res));
      })
    }
  }

  uploadFile(): void {
    if (this.selectedFile) {
      this.service.reader(this.selectedFile).subscribe(res=>{
        this.data=JSON.parse(JSON.stringify(res));
      })
    } else {
      console.log('No file selected.');
      console.log('please choose a file')
    }
  }
}